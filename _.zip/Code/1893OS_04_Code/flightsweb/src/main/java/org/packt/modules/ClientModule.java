package org.packt.modules;

import com.google.inject.AbstractModule;

public class ClientModule extends AbstractModule {
	@Override
	protected void configure() {
	}
}
