package org.packt.supplier;

import java.util.Set;

public interface FlightSupplier {
	Set<SearchResponse> getResults();
}
