package org.packt.client.utils;

public enum OutputPreference {
	FARE,DURATION
}
