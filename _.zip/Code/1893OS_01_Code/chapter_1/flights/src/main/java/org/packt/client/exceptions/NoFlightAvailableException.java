package org.packt.client.exceptions;

public class NoFlightAvailableException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8019996726088255419L;

	public NoFlightAvailableException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NoFlightAvailableException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NoFlightAvailableException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NoFlightAvailableException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
