package org.packt.utils;

public enum OutputPreference {
	FARE,DURATION
}
