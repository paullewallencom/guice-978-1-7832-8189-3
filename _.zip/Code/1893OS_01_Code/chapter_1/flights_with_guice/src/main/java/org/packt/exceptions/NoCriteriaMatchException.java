package org.packt.exceptions;

public class NoCriteriaMatchException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8389879472090644603L;

	public NoCriteriaMatchException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NoCriteriaMatchException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NoCriteriaMatchException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NoCriteriaMatchException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
