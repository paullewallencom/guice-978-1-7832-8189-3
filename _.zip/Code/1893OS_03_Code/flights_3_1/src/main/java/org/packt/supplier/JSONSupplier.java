package org.packt.supplier;

import java.util.Set;

public class JSONSupplier implements FlightSupplier {

	@Override
	public Set<SearchRS> getResults() {
		return null;
	}

}
