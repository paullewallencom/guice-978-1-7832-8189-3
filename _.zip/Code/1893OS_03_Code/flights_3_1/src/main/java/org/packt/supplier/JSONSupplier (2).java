package org.packt.supplier;

import java.util.Set;

public class JSONSupplier implements FlightSupplier {

	@Override
	public Set<SearchResponse> getResults() {
		return null;
	}

}
