package org.packt.exceptions;

public class NoExcelAvailableException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
